# Hero Run 2

Hero Run 2 is a browser-based 3D endless runner adapted from the supplied `HeroRun_Unity1.zip` source. It uses HTML, CSS, JavaScript, Three.js and Vite. It does **not** require Unity or C#.

## What was carried over from the supplied source

The supplied Unity C# project describes a small action platformer with a hero controller, a double-jump, attack and special attack, enemies, coins, time shards, health pickups, and mobile touch controls. This web edition adapts those playable ideas into a three-lane 3D runner:

- Automatic forward running and smooth lane switching.
- Animated low-poly hero with running, jumping, double-jump, sliding, attack and special-attack poses.
- Enemies that can be defeated with J / Hit or K / Special.
- Coins, time shards, health pickups, shield, magnet, speed and double-jump boosts.
- Crates and spike obstacles, health, distance, score, best distance and local progress saving.
- Keyboard and mobile touch controls; pause on tab/app hide.
- Procedurally created 3D world, lighting, shadows, scenery, particle bursts and synthesized sound effects.

## Controls

| Action | Keyboard | Touch |
|---|---|---|
| Change lane | A / D or Left / Right | Left / Right |
| Jump / double-jump | Space, W or Up | Jump |
| Slide | S or Down | Slide |
| Attack | J | Hit |
| Special attack | K | ⚡ |
| Pause | Pause button | Pause button |

## Run locally

Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. For a production build:

```bash
npm test
npm run build
npm run preview
```

The built site is written to `dist/`.

## Deploy

The project is a static web app and can be deployed to GitHub Pages, Cloudflare Pages, Netlify or any static hosting service. For GitHub Pages, set the build command to `npm run build` and the publish directory to `dist`. `vite.config.js` uses a relative base path to support project pages.

## What is not included

The supplied C# source references Unity Netcode, Unity Lobby and Unity Relay for online rooms. Those services are Unity-specific and are not included in this browser-only conversion. This version is a local single-player game; it does not claim to provide online multiplayer, cloud saves, server leaderboards, ads, or in-app purchases. Those require a separate backend and security design.

## Source reference

The original C# files from the uploaded ZIP are preserved under `reference/unity-source/` for traceability. They are reference material only; the browser game runs from `src/`.

A GitHub Actions workflow is included at `.github/workflows/deploy.yml`. After pushing to the `main` branch, enable GitHub Pages with **GitHub Actions** as the build/deploy source in repository Settings > Pages. The workflow installs dependencies, runs tests, builds the site and deploys `dist/`.
